

library(tidyverse)
library(dplyr)

# Data Transformation using dplyr

#Lets examine the diamonds data set
diamonds

#?diamonds

# Filtering  (selecting observations using their values)   filter

# Choose only observations with a depth of 65.1

filter(diamonds, depth==65.1) ->diamonds1
diamonds1

# Choose only observations with a depth of 65.1 a table value of 58
# (different column variables)
filter(diamonds, depth==65.1 , table==58) -> diamonds2
diamonds2

# Choose only observations with a depth of 65.1 or a depth of 62.3
# (same column variable)
filter(diamonds,depth==65.1|depth==62.3)-> diamonds3
diamonds3 

#Produce more than the default 10 rows.

print(diamonds3,  n=25)

#Choose only observations that have a depth that is greater than 65
filter(diamonds, depth > 65) -> diamonds4
diamonds4

#Choose only observations that have a color of E and a price that is 
#less than 338

filter(diamonds, color == "E", price < 338 ) -> diamonds5
diamonds5

#Choose only observations that have a premium cut, a clarity of WS1,
#and a length that is greater than or equal to 3

filter(diamonds, cut =="Premium" , clarity == "VVS1" , 
                  x >= 3)->diamonds6
diamonds6

#Choose only observations that have carat values between .25 and .45   Print 30 rows.

filter(diamonds, carat< .45 & carat > .25)-> diamonds77
diamonds77

print(diamonds77 , n=30)


# Arrange (changing the order of columns) 

#List the values of price from highest to lowest
arrange(diamonds,  desc(price))-> diamonds7
diamonds7


#List the values of price from lowest to highest. Print the first 20 rows
diamonds8 <- arrange (diamonds, price)
diamonds8
print(diamonds8, n=20)

#A comment about missing values
#Missing values are sorted at the end. The sort maybe ascending or
#descending


#Ascending
df<- tibble(x = c(5, 2, NA))
arrange(df, x)


#Descinding
ef<- tibble(x = c(5, 2, NA))
arrange(df, desc(x))


# Select  (Choosing column variables)   


# From the diamonds data set choose only columns color, depth, x, y, and z

select(diamonds, color,depth, x, y, z)-> diamonds8.5
diamonds8.5

# From the diamonds data set choose only columns carat, cut, and
# price

select(diamonds, carat, cut, price)-> diamonds9
diamonds9

# Change the order of the selection to price, cut, and then carat

select(diamonds, price, cut, carat)->diamonds10
diamonds10


# Deselect the columns price,carat

select(diamonds,  -price, -carat) -> diamonds11
diamonds11

#Mutate  (Adding columns to your data frame)

#Create a narrower data frame from diamonds
diamonds12<-select(diamonds, clarity,cut,price)
diamonds12

#Now add a variable column that decreases every price by 50
mutate(diamonds12,  dp = price-50)-> diamonds13
diamonds13

#Now add a variable that gives a ratio of dp to price
mutate(diamonds13, ratio = (dp/price)) -> diamonds14
diamonds14

#Lets increase the output observations
print(diamonds14, n=50)


#Lets change the name of an observation item (We will capitalize Ideal
#of the cut column) Use the functions mutate and recode

diamonds14

mutate(diamonds14, cut = recode(cut, "Ideal"= "IDEAL"))->
  diamonds15
diamonds15


# Transforming a data frame using the pipping process
# pipe operator  %>%

#Example 1
#From the diamonds data frame choose the variables price, x and y

diamonds%>%
  select(price,x,y)


#Example 2
#From the diamonds data frame, create a data frame that shows the 
#variables price and carat, but for only price values in descending
#order.  Print the first 20 rows. 
diamonds%>%
  select(price,carat)%>%
  arrange(desc(price))%>%
  print(n=20)


#Example 3
#From the diamonds data frame, create a data frame that shows the 
#variables price, carat and cut, but for only price values in descending
#order that are less than or equal to 400.  Print the first 15 rows.

diamonds%>%
  select(price,carat,cut)%>%
  filter(price<=400)%>%
  arrange(desc(price))%>%
  print(n=15)



#Example 4
#From the diamonds data frame, create a data frame that shows the 
#all variables except x, y, and z, but for only price values in descending
#order that are between 18000 and 18500 and only for cuts that are Very Good.
# Print the first 25 observations
diamonds%>%
  select(-x, -y, -z)%>%
  filter(price < 18500, price >18000)%>%
  filter(cut == "Very Good")%>%
  arrange(desc(price))%>%
  print(n=25)


# lets compare methods for using dplyr functions to modify a data
#frame

# Example 1

# From the diamonds data frame choose only price values that are greater than 17000

# assigning to a variable
diamonds
k <-filter( diamonds,  price > 17000)
k

# Using the pipe process

diamonds %>%
  filter( price > 17000)


# Example 2

#From the diamonds data frame, create a data frame that shows the 
#variables price, carat and cut, but for only price values in descending
#order that are less than or equal to 400.  Print the first 15 rows.

#  Assigning Method

diamonds
A <- select(diamonds, price, carat, cut)
A
diamonds
B <- filter(A, price <= 400)
B
diamonds
C <- arrange(B, desc(price))
C  
print (C,  n = 15)


# Pipping Method

diamonds%>%
  select(price,carat,cut)%>%
  filter(price<=400)%>%
  arrange(desc(price))%>%
  print(n=15)




#Group by and Summarize

AA <-tribble(
  ~Name,      ~Gender,    ~PolParty,        ~Salary,  ~Age,
  "Ron",      "Male",       "Dem",           45000,     22,
  "Mary",     "Female",     "Rep",           53000,     25,
  "Juan",     "Male",       "Dem",           58000,     27,
  "Lindsy",   "Female",     "Rep",           50500,     30,
  "Abdul",    "Male",       "Dem",           61200,     32,
  "Leon",     "Male",       "Rep",           57200,     28,
  "Alice",    "Female",     "Dem",           60200,     25
)
AA

#Two ways to find the mean of a variable in a data frame

summary(AA)

summarise(AA, meansalary = mean(Salary))

# Now let's use the commands group by / summarize to find summary
#statistics for a levels of a categorical variable

# (I want the mean salaries for men and women separately)

AA %>%
  group_by(Gender) %>%
  summarise(MeanSalary = mean(Salary))


# (Now I want the mean salaries for men and women grouped by political party)

AA %>%
  group_by(Gender , PolParty) %>%
  summarise(MeanSalary = mean(Salary))


# Another Example


# For the mpg data frame let's find the average city miles per gallon
# for ford vehicles only.

mpg

mpg%>%
  select (manufacturer, cty) %>%
  filter (manufacturer == "ford")%>%
  print(n = 25)


mpg%>%
  select(manufacturer , cty)%>%
  group_by(manufacturer == "ford") %>%
  summarise(AverageCityMileage = mean(cty))









```
